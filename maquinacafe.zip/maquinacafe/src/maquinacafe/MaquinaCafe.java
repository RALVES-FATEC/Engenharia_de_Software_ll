/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maquinacafe;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

/**
 * Sistema de Máquina de Café baseado em UML
 * Construído com First Principle Thinking para coesão de estados.
 */
public class MaquinaCafe {

    public static void main(String[] args) {
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        try (Scanner leitor = new Scanner(System.in, "UTF-8")) {
            Estoque estoque = new Estoque();
            MaquinaDeCafe hardwareMaquina = new MaquinaDeCafe();
            RealizarPedido sistema = new RealizarPedido(estoque, hardwareMaquina);

            hardwareMaquina.ligar();
            System.out.println("\n========================================");
            System.out.println("  ☕ BEM-VINDO À MÁQUINA DE CAFÉ JAVA ☕  ");
            System.out.println("========================================");

            while (true) {
                estoque.exibirPainelLuzes();

                System.out.print("\nQual sabor você deseja? (ou digite 'sair'): ");
                String escolhaSabor = leitor.nextLine();

                if (escolhaSabor.equalsIgnoreCase("sair")) {
                    break;
                }

                sistema.selecionarSabor(escolhaSabor);

                if (!sistema.verificarDisponibilidade()) {
                    System.out.println(sistema.exibirMensagemErro());
                    System.out.println("--- Pressione ENTER para continuar ---");
                    leitor.nextLine();
                    continue;
                }

                System.out.println("Selecione o Adoçante:");
                System.out.println("1 - Nenhum | 2 - Açúcar | 3 - Adoçante");
                System.out.print("Opção: ");
                String escolhaAdocante = leitor.nextLine();
                sistema.escolherAdocante(escolhaAdocante);

                System.out.print("\nForma de Pagamento (1-Pix | 2-Cartão): ");
                try {
                    int pgto = Integer.parseInt(leitor.nextLine());
                    sistema.processarPagamento(pgto);
                    sistema.finalizarPedido();
                } catch (NumberFormatException e) {
                    System.out.println(">>> ERRO: Entrada inválida. Pedido cancelado.");
                }

                System.out.println("\n--- Pressione ENTER para o próximo cliente ---");
                leitor.nextLine();
            }

            System.out.println("Desligando máquina... Até logo!");
        }
    }
}

// --- 1. ENUMERAÇÕES (Definição de Estados conforme UML) ---
enum StatusPagamento {
    APROVADO, PENDENTE, RECUSADO;
}

enum NivelEstoque {
    ALTO, MEDIO, VAZIO;
}

enum TipoAdocante {
    NENHUM, ACUCAR, ADOCANTE;
}

enum StatusPedido {
    CRIADO, EM_PREPARO, RETIRADA, CONCLUIDO;
}

// --- 2. INTERFACE (Contrato de Pagamento) ---
interface MetodoPagamento {
    boolean pagarPix(double valor);
    boolean pagarCartao(double valor);
}

// --- 3. ENTIDADES DE DADOS ---
class Sabor {
    private String nomeSabor;
    private int qtdSabor;
    private int quantidadeMaxima = 30;
    private int quantidadeAtual;

    public Sabor(String nomeSabor, int quantidadeAtual) {
        this.nomeSabor = nomeSabor;
        this.quantidadeAtual = Math.min(quantidadeAtual, quantidadeMaxima);
    }

    public String getNomeSabor() { return nomeSabor; }
    public int getQuantidadeAtual() { return quantidadeAtual; }

    public void reduzirQuantidade() {
        if (quantidadeAtual > 0) quantidadeAtual--;
    }
}

class DetalhesPedido {
    private int idPedido;
    private Date data;
    private Double preco;
    private StatusPagamento statusPagamento;

    public DetalhesPedido(int idPedido, Double preco) {
        this.idPedido = idPedido;
        this.preco = preco;
        this.data = new Date();
        this.statusPagamento = StatusPagamento.PENDENTE;
    }

    public void setStatusPagamento(StatusPagamento status) {
        this.statusPagamento = status;
    }
    public StatusPagamento getStatusPagamento() { return statusPagamento; }
    public Double getPreco() { return preco; }
}

// --- 4. HARDWARE E ESTOQUE ---
class Estoque {
    private List<Sabor> sabores = new ArrayList<>();
    private Double qtdAgua = 2000.0; // em ml
    private int qtdCopos = 50;

    public Estoque() {
        sabores.add(new Sabor("Expresso", 30));
        sabores.add(new Sabor("Capuccino", 30));
        sabores.add(new Sabor("Macchiato", 5));  // MEDIO
        sabores.add(new Sabor("Latte", 0));      // VAZIO
        sabores.add(new Sabor("Mocha", 30));
    }

    public List<Sabor> getSabores() { return sabores; }

    public boolean verificarDisponibilidade() {
        return qtdAgua >= 100 && qtdCopos > 0;
    }

    public void reduzirQuantidade() {
        qtdAgua -= 100;
        qtdCopos--;
    }

    public NivelEstoque verificarNivel(Sabor sabor) {
        if (sabor.getQuantidadeAtual() == 0) return NivelEstoque.VAZIO;
        if (sabor.getQuantidadeAtual() <= 10) return NivelEstoque.MEDIO;
        return NivelEstoque.ALTO;
    }

    public void verificarQtdAgua() {
        System.out.println("Água disponível: " + qtdAgua + "ml");
    }

    public void verificarQtdCopos() {
        System.out.println("Copos disponíveis: " + qtdCopos);
    }

    public void exibirPainelLuzes() {
        System.out.println("\n===== PAINEL DE DISPONIBILIDADE =====");
        for (Sabor s : sabores) {
            System.out.printf("Sabor: %-10s | Doses: %-2d | Status: [%s]\n", 
                s.getNomeSabor(), s.getQuantidadeAtual(), verificarNivel(s));
        }
        System.out.println("=====================================");
    }
}

class MaquinaDeCafe {
    public boolean ligar() {
        System.out.println("Iniciando sistemas da máquina...");
        return true;
    }

    public boolean prepararBebida(String saborPedido, DetalhesPedido detalhes) {
        if (detalhes.getStatusPagamento() == StatusPagamento.APROVADO) {
            System.out.println("\n[MÁQUINA] Aquecendo água e moendo grãos para: " + saborPedido.toUpperCase());
            acionarTimer(2); // Inovação: Simula o tempo de preparo
            return true;
        }
        return false;
    }

    public void acionarTimer(int segundos) {
        try {
            for (int i = segundos; i > 0; i--) {
                System.out.print(". ");
                Thread.sleep(1000); // 1 segundo real
            }
            System.out.println("\n[MÁQUINA] Bipe! Bebida pronta.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

// --- 5. LÓGICA DE PROCESSO DE NEGÓCIO ---
class RealizarPedido implements MetodoPagamento {
    private String saborPedido;
    private TipoAdocante tipoAdocante;
    private Estoque estoque;
    private StatusPedido statusPedido;
    private DetalhesPedido detalhesAtuais;
    private MaquinaDeCafe maquina;
    private String mensagemErro = "";

    public RealizarPedido(Estoque estoque, MaquinaDeCafe maquina) {
        this.estoque = estoque;
        this.maquina = maquina;
        this.statusPedido = StatusPedido.CRIADO;
    }

    public void selecionarSabor(String sabor) {
        this.saborPedido = sabor;
        this.detalhesAtuais = new DetalhesPedido((int)(Math.random() * 1000), 5.00);
        this.statusPedido = StatusPedido.CRIADO;
    }

    public String escolherAdocante(String opcao) {
        switch(opcao) {
            case "2": this.tipoAdocante = TipoAdocante.ACUCAR; break;
            case "3": this.tipoAdocante = TipoAdocante.ADOCANTE; break;
            default: this.tipoAdocante = TipoAdocante.NENHUM; break;
        }
        return this.tipoAdocante.name();
    }

    public boolean verificarDisponibilidade() {
        if (!estoque.verificarDisponibilidade()) {
            mensagemErro = ">>> ERRO: Máquina sem água ou copos suficientes.";
            return false;
        }
        for (Sabor s : estoque.getSabores()) {
            if (s.getNomeSabor().equalsIgnoreCase(saborPedido)) {
                if (s.getQuantidadeAtual() > 0) {
                    return true;
                } else {
                    mensagemErro = ">>> ERRO: Sabor " + saborPedido + " está esgotado (VAZIO).";
                    return false;
                }
            }
        }
        mensagemErro = ">>> ERRO: Sabor não encontrado no cardápio.";
        return false;
    }

    public String exibirMensagemErro() {
        return this.mensagemErro;
    }

    public void processarPagamento(int opcaoPgto) {
        boolean sucesso = (opcaoPgto == 1) ? pagarPix(detalhesAtuais.getPreco()) : pagarCartao(detalhesAtuais.getPreco());
        
        if (sucesso) {
            detalhesAtuais.setStatusPagamento(StatusPagamento.APROVADO);
            System.out.println(">>> PAGAMENTO APROVADO!");
        } else {
            detalhesAtuais.setStatusPagamento(StatusPagamento.RECUSADO);
            System.out.println(">>> ERRO: Pagamento Recusado pela operadora.");
        }
    }

    public void finalizarPedido() {
        if (detalhesAtuais.getStatusPagamento() == StatusPagamento.APROVADO) {
            this.statusPedido = StatusPedido.EM_PREPARO;
            
            // Abate do estoque (Água, Copo e Sabor)
            estoque.reduzirQuantidade();
            for (Sabor s : estoque.getSabores()) {
                if (s.getNomeSabor().equalsIgnoreCase(saborPedido)) s.reduzirQuantidade();
            }

            // Manda para o hardware
            maquina.prepararBebida(saborPedido, detalhesAtuais);
            
            this.statusPedido = StatusPedido.RETIRADA;
            System.out.println(">>> Adicionado: " + tipoAdocante);
            System.out.println(">>> COPO CHEIO! Pode retirar sua bebida.");
            this.statusPedido = StatusPedido.CONCLUIDO;
        }
    }

    @Override
    public boolean pagarPix(double valor) {
        System.out.println("Gerando QR Code Pix de R$" + valor + "...");
        return true; // Simulação de sucesso
    }

    @Override
    public boolean pagarCartao(double valor) {
        System.out.println("Processando Cartão de R$" + valor + "...");
        return true; // Simulação de sucesso
    }
}